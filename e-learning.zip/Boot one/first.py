# print("vishal sharma")
# x = 5
# del x
# print(x)

# x = 10  #global variable 
# def exe_function(): #local variable
#     y = 10
#     print(y)
#     print(x)
#     exe_function()
# print(x)

# s = 5
# t = 3
# vt = s%t
# print("Print the modlus=>",vt)

# a = 6
# b = 10

# if a>b :
#     print("yes it's greater")
# else :
#     {
#         print("not greater ")
#     }   

# age_category_0 = 100

# if(age_category_0>=18):
#     {
#       print("yes! you can vote now")
#     }
# elif(age_category_0>=25):
#     {
#         print("Yes! you also vote now")
#     }
# elif(age_category_0>=50):
#     {
#         print("Yes! yaa you absolutely vote now ")
#     }
# else:
#     {
#         print("No! you are not available for vote")
#     }

  
# num = 1
# for i in range(1 , 11, 1):
#        print(i*num)

# boys_name = {"vishal","raja","mohan"}
# for x in boys_name:
#            print("This is a list ", boys_name)


#  We should print the student grades in the basis of student marks

# student_marks = 74  # we can take the marks from the user as a input
# if(student_marks<=100 and student_marks>=90): 
#     print("Grade will be A++")
# elif(student_marks<=90 and student_marks>=80):
#     print("Grade will be A")
# elif(student_marks<=80 and student_marks>=70):
#     print("Grade will be B++")
# elif(student_marks<=70 and student_marks>=60):
#     print("Grade will be C")
# else:
#     print("Fail:Dont be nervous please keep it up!")

# dict = {"Name":"vishal","Class":"MSC(AI)","Address":"Goh Aurangabad bihar",}
# print(type(dict)) #its declare the type of class   
# for x in dict:  # its for loop here
#     print(dict)
       

# write a program to print the prime factor that we can take a input as a integer.?

num = int(input("Here! we can take prime number to product the number "))
 


    