<?php
$db_hostname = "127.0.0.1";
$db_username = "root";
$db_password = "";
$db_name = "signup";


$conn = mysqli_connect($db_hostname , $db_username, $db_password , $db_name);

if(!$conn)
{
    echo"Connection failed" . mysqli_connect_error();
    exit;
}

  $name = $_POST['name'];
  $email = $_POST['email'];
  $password = $_POST['password'];

  $sql =    INSERT INTO (name , email, password) values('$name','$email','$password');

  $result = mysqli_query($conn, $sql);
  
  if(!$result)
  {
echo "Error".mysqli_erro($conn);
exit;

 mysqli_close($conn);
  }
?>